#ifndef _FILE_MANAGEMENT_
	#define _FILE_MANAGEMENT_
	extern void openFile(char filename[], char mode[], FILE **filePointer);
#endif
